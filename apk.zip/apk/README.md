您即将下载最新版的 Android Hosts-L V6.23 Stable(V6.20之前的版本停止更新！)
===============
V6.23：增加“激活Google位置记录”的功能。
[点我下载](https://github.com/lack006/Android-Hosts-L/raw/master/apk/Android_Hosts-L.apk)
===============
或
===============
[跳转网盘](http://t.cn/Rv7Rr1c)
===============

